URL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=136&event=149
Difficulty: st3
No misalignments compared to `Jungfrau_template._bms` except additional keysound definitions' extension (ogg -> wav).

BOF:21差分企画: https://darksabun.github.io/event/bof21/