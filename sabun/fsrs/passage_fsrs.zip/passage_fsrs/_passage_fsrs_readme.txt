URL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=320&event=149
Difficulty: st3
Additional keysounds included (bre aware of subfolders...)

BOF:21差分企画: https://darksabun.github.io/event/bof21/