URL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=105&event=152
Difficulty: st3
No misalignments compared to `_temp.xxx`.

BOF:22差分企画: https://darksabun.github.io/event/bof22/