URL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=66&event=152
Difficulty: sl11
No misalignments compared to `_TOXIC_ENGINE_N.bms`.

BOF:22差分企画: https://darksabun.github.io/event/bof22/