a) 배정 배율 및 찬스 사용 여부 / 割り当て倍率およびチャンスの使用有無 / Assigned multiplier and whether a Chance was used
188 / No

b) 선택 난이도 / 選択した難易度 / Selected difficulty
★15

c) 유효한 본체 URL / 本体URL / Valid BMS URL
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=348&event=137

d) 기준이 되는 동봉 패턴 또는 키음 어레인지 여부 / 基準となる同梱譜面、またはキー音アレンジの有無 / Packaged chart on which the submitted chart is based, and whether any keysound arrangement was applied.
Packaged chart includes lots of misaligned and duplicated keysounds. Therefore, such objects are realigned and removed.

e) 기타 코멘트 / その他コメント / Other comments
내 앞마당에 쏘려던 폭죽이 현해탄을 넘어갔을 때...