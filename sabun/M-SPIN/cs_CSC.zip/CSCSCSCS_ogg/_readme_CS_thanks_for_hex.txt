http://web.archive.org/web/20060621123759/http://www.remarkablesense.org:80/~hal/waveceptor/bms/bms_crystal.zip

一部の音源はhexさんのCrystal Snow[Hexagon]差分に基づいています。
https://bms.hexlataia.xyz/tables/hexajoy.html

2022-12-24
https://fsrs.github.io/