BMS chart Editors’ League
https://darksabun.github.io/event/bcel/venue/

BMS SEARCH venue: BMS chart Editors’ League -Freestyle-
https://venue.bmssearch.net/bcel_free

URL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=340&event=137
Difficulty: ★★3 (~st4?)
Comment: _Kanon_Empty.xxx基準
やむを得ずテストプレイなしで提出。
この差分によるすべての苦痛にお詫び申し上げます。