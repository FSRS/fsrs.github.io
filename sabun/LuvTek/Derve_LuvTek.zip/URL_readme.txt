http://manbow.nothing.sh/event/event.cgi?action=More_def&num=310&event=127

No misalignments compared to the hidden temp file `Derve[Blank].bofxv19`, but duplicate keysounds have been removed.