https://venue.bmssearch.net/bmscoycc/8
SPB基準にキー音追加