﻿BOFU2016 Out of the System
http://manbow.nothing.sh/event/event.cgi?action=More_def&num=366&event=110

Please insert the bmp file with bms files in the folder.
**Keysounds have high volume. Use BVlm and adjust the volume (about -300%dB) or you may SUFFER from distorted sound (over 0dB).

동봉된 bmp 파일을 차분과 함께 폴더에 넣어주세요
**키음의 음압이 상당히 높습니다. 청취환경에 따라 음이 찢어지는 듯한 왜곡 현상이 일어날 수 있으니, BVlm을 사용하여 키음의 볼륨을 조정해주세요. (-300%dB 정도) 

同梱のbmpファイルを差分と一緒にフォルダに入れてください。
**キー音の音圧がかなり高いです。音割れが起こりうるので、BVlmを使用してキー音の音圧を調整してください。 (-300%dBくらい)

BVlm DL Link
https://cerebralmuddystream.nekokan.dyndns.info/