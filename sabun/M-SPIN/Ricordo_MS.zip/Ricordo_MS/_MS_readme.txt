URL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=188&event=152
Difficulty: ★23

No misalignments compared to `Ricordo_allBGM._bms` except additional keysound definitions' extension (ogg -> wav).

BOF:22差分企画: https://darksabun.club/event/bof22/