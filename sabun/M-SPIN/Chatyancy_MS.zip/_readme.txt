https://manbow.nothing.sh/event/event.cgi?action=More_def&num=251&event=140

DIFFICULTY: st2
NOTES: 2567
TOTAL: 369
JUDGERANK: EASY

同梱_Chatyancy_allBGM._bms基準