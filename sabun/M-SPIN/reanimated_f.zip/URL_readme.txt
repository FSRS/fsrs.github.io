﻿http://manbow.nothing.sh/event/event.cgi?action=More_def&num=438&event=116

キー音ファイルの定義を.oggから.wavに変更しました。
差分と同梱の(スライス)キー音ファイルを必ず一緒に入れてください。
ズレ検査の結果は、それを示したもので実質ズレはありません。

