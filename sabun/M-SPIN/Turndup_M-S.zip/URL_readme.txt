﻿http://manbow.nothing.sh/event/event.cgi?action=More_def&num=448&event=104

N音源基盤にAキー音を一部使用
(trr_000.wav, trr_001.wav to kickfill_1_020-043)

https://fsrs.github.io/