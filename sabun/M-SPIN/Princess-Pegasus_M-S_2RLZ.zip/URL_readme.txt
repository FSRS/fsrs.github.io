﻿http://manbow.nothing.sh/event/event.cgi?action=More_def&num=18&event=129

SPN音源をベースにキー音を追加しました。

NOTES 2949
TOTAL 573
JUDGERANK EASY
DIFFICULTY 23 (~st3)

2RLZ
https://2rlz.github.io/

fsrs
https://fsrs.github.io/