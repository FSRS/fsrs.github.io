http://manbow.nothing.sh/event/event.cgi?action=More_def&num=310&event=127

no_keysound_Diff_with_NORMAL_chart