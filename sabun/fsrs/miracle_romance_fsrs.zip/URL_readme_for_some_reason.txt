http://manbow.nothing.sh/event/event.cgi?action=More_def&num=312&event=127

HARD音源基盤
#044-045にキー音を任意追加