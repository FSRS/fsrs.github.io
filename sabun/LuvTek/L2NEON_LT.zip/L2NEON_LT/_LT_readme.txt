URL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=56&event=152
Difficulty: st4
No misalignments compared to `L2NEONtext6_bms_blue0927.XXX`.

BOF:22差分企画: https://darksabun.github.io/event/bof22/